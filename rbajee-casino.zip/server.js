
const express = require("express");
const fs = require("fs");
const app = express();
const port = 3000;

app.use(express.static("public"));
app.use(express.json());

let balance = 1000;

app.post("/api/bet", (req, res) => {
    const amount = Number(req.body.amount);

    if (amount > balance) {
        return res.json({status:"fail", message:"Not enough balance", balance});
    }

    const result = Math.random();

    if(result > 0.5){
        balance += amount;
        res.json({status:"win", balance});
    } else {
        balance -= amount;
        res.json({status:"lose", balance});
    }
});

app.listen(port, () => {
    console.log("Casino server running on http://localhost:" + port);
});
