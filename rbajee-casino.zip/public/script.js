
function bet(){
    const amount = document.getElementById("betAmount").value;

    fetch("/api/bet",{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({amount:Number(amount)})
    })
    .then(res=>res.json())
    .then(data=>{
        document.getElementById("balance").innerText = data.balance;

        if(data.status==="win"){
            alert("You Win!");
        }else if(data.status==="lose"){
            alert("You Lose!");
        }else{
            alert(data.message);
        }
    })
}
